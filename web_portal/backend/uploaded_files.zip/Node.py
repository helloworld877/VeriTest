class Node:

    def __init__(self, isFinal = False, isStart = False):
        self.isFinal = isFinal
        self.isStart = isStart
        self.index = None
        self.isDummy = False
        self.list_of_nodes = list() ## FOR DFA
    

    def __str__(self) -> str:
        if self.isDummy:
            return ""
        
        else:
            return "S" + str(self.index)
        

        